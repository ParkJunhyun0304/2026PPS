#include <iostream>

using namespace std;

int main() {
    unsigned long long a,b,c;
    
    cin >> a >> b >> c;

    cout << a+b+c << endl;
}